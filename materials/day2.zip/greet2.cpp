#include <iostream>

void greet()
{
  std::cout << "Greetings, everyone!" << std::endl;
}

int main()
{
  greet();
  return 0;
}
