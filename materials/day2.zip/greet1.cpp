#include <iostream>

int main()
{
  std::cout << "Greetings, everyone!" << std::endl;
  return 0;
}
