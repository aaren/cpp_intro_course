#include <iostream>

int main()
{
  greet();
  return 0;
}

void greet()
{
  std::cout << "Greetings, everyone!" << std::endl;
}
