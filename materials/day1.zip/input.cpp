// Example of chaining stream extractions

#include <iostream>

using namespace std;

int main()
{
    int x, y;

    cout << "Enter two integers: ";
    cin >> x >> y;

    cout << "You entered " << x << " and " << y << endl;

    return 0;
}
