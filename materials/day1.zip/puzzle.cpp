#include <iostream>

using namespace std;


int main()
{
  int x;
  cout << "Enter value of x: ";
  cin >> x;

  if (x = 0)
    cout << "x is zero!" << endl;
  else
    cout << "x is non-zero!" << endl;

  return 0;
}
