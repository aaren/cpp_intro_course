/*
   "Introduction to C++ Programming" Day 1 Exercises: loop.cpp

   An infinite loop.  Ctrl-C will terminate it...
*/

#include <iostream>

using namespace std;

int main()
{
  while (true) {
    cout << "Help!" << endl;
  }

  return 0;
}
