// Example of a for loop

#include <iostream>

using namespace std;


int main()
{
  for (int i = 10; i > 0; --i)
    cout << i << '\n';

  cout << "Lift off!" << endl;

  return 0;
}
