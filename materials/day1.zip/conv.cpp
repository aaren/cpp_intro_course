int main()
{
  short s = 100000;
  int i = 27.5;
  float f = 3.141;

  return 0;
}
