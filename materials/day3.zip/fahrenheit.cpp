#include "temperature.hpp"

namespace temperature
{
  double fahrenheit(double c)
  {
    return 9*c/5 + 32;
  }
}
