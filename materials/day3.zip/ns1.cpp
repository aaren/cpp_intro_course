// Namespaces example

#include <iostream>


int main()
{
  int cout = 42;   // no clash with std::cout

  std::cout << "Hello, World!" << std::endl;

  return 0;
}
